# 🌮 The Little Taco Shop

A beginner HTML5 project based on the **HTML Project** at the end of the freeCodeCamp/Dave Gray HTML tutorial.

## Pages

- `index.html` — home page, about section, taco menu table
- `hours.html` — store hours
- `contact.html` — contact form and address
- `css/styles.css` — shared styling
- `images/` — local SVG artwork and favicon

## How to run

Open `index.html` in a browser. No build tools or dependencies are required.

## GitHub

```bash
git init
git add .
git commit -m "Complete Little Taco Shop HTML project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/little-taco-shop.git
git push -u origin main
```

The project intentionally uses semantic HTML elements such as `header`, `nav`, `main`, `article`, `aside`, `figure`, `table`, `form`, `fieldset`, `legend`, and `address`.
